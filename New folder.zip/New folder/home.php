<?php

?>
<!DOCTYPE HTML>
<!DOCTYPE html>
<html>
<head>
	<!-- This how we can linl--><link rel="stylesheet" type="text/css" href="style.css">
	<title>My first website</title>
	
</head>
<body style="background-color:#808080">
	<div id="top-bar">
		<center>
			<img src="images/logo.png" class="logo">
			<h1 style="color:#DAA520">Research Conclave, 2020</h1>
			<h2  style="color:#DAA520">Indian Institute of Technology Guwahati , Assam</h2>
		</center>
	</div>
	<div id="main-wrapper1" >
		<center>
			<h2 style="color:#00008B">Home Form</h2>
		</center>
		<form name="myform" action="home.php" method="post">
			<center>
				<a href="index.php"><input type="button" id="logout_btn" value="Log Out">
			</center>
			
		</form>

	</div>	
</body>
</html>